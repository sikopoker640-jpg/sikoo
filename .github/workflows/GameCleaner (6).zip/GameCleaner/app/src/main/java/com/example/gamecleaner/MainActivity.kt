package com.example.gamecleaner

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var sw: Switch
    private lateinit var status: TextView
    private var ignore = false

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun field(e: EditText) = e.apply {
        setPadding(dp(14), dp(12), dp(14), dp(12)); textSize = 15f
        background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.WHITE); setStroke(dp(1), 0xFFD0D5DD.toInt()) }
        (layoutParams as? LinearLayout.LayoutParams)
    }

    private fun btn(t: String, c: Int) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(c) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24))
            setBackgroundColor(0xFFF2F4F8.toInt()); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun add(v: View, top: Int = 12) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        }
        add(TextView(this).apply { text = "Game Cleaner"; textSize = 26f; setTextColor(0xFF101828.toInt()); setTypeface(typeface, android.graphics.Typeface.BOLD) }, 0)
        add(TextView(this).apply { text = "کونترۆلا یاریان ب شێوەیێ ئۆتۆماتیک"; textSize = 14f; setTextColor(0xFF667085.toInt()) }, 2)

        sw = Switch(this).apply { text = "دەستپێکرن (هەر 1 دەقە)"; textSize = 19f; setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.WHITE) } }
        add(sw, 20)
        status = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFF667085.toInt()) }
        add(status, 8)

        add(TextView(this).apply { text = "پاکێجێن یاریان (یا یەکەم = پوکر)"; textSize = 14f; setTextColor(0xFF344054.toInt()) }, 20)
        val et = field(EditText(this).apply { minLines = 4; gravity = Gravity.TOP; setText(prefs.getString("list", "com.boyaa.androidmarketar")) })
        add(et, 6)
        val mail = field(EditText(this).apply { hint = "Gmail: example@gmail.com"; setText(prefs.getString("mail", "")) })
        add(mail, 10)
        val xy = field(EditText(this).apply { hint = "x,y دوگمەیا Sign in with Google"; setText(prefs.getString("xy", "0.20,0.81")) })
        add(xy, 10)
        val ck = field(EditText(this).apply { hint = "x,y خانەیا قرات ووافقت"; setText(prefs.getString("ck", "0.32,0.71")) })
        add(ck, 10)
        val cb = CheckBox(this).apply { text = "Game Play: داتایا یاریێ ل Play Games بسڕە (بەرێ هەر جارەکێ)"; isChecked = prefs.getBoolean("cb", false) }
        add(cb, 10)
        val pk = CheckBox(this).apply { text = "Poker: ڤەکرن و لۆگینا Google و Continue"; isChecked = prefs.getBoolean("pk", true) }
        add(pk, 10)
        val clr = CheckBox(this).apply { text = "داتایا خودی یاریێ ژی بسڕە (Clear data)"; isChecked = prefs.getBoolean("clr", false) }
        add(clr, 6)
        val url = field(EditText(this).apply { hint = "لینکا Play Games"; setText(prefs.getString("url", ClearService.DEF_URL)) })
        add(url, 10)
        val gname = field(EditText(this).apply { hint = "ناڤێ یاریێ ل Play Games"; setText(prefs.getString("gname", ClearService.DEF_GAME)) })
        add(gname, 10)

        fun save() = prefs.edit().putString("list", et.text.toString()).putString("mail", mail.text.toString())
            .putString("xy", xy.text.toString()).putString("ck", ck.text.toString()).putBoolean("cb", cb.isChecked).putBoolean("clr", clr.isChecked).putBoolean("pk", pk.isChecked)
            .putString("url", url.text.toString()).putString("gname", gname.text.toString()).apply()

        val once = btn("تێست: تنێ جارەکێ", 0xFF475467.toInt())
        once.setOnClickListener {
            save()
            val s = ClearService.inst
            if (s == null) needService() else s.begin(false)
        }
        add(once, 16)
        add(btn("کرنا خزمەتێ ل Accessibility", 0xFF1D6FE8.toInt()).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, 8)
        add(TextView(this).apply {
            text = "دوگمەیەکا ژێر شاشەیێ (ON/OFF) دێ ل سەر هەمی شاشەیان دیار بیت. بۆ ڕاگرتنێ، لێ بدە."
            textSize = 12f; setTextColor(0xFF667085.toInt()) }, 12)

        sw.setOnCheckedChangeListener { _, on ->
            if (ignore) return@setOnCheckedChangeListener
            save()
            val s = ClearService.inst
            if (on) {
                if (s == null) { ignore = true; sw.isChecked = false; ignore = false; needService() }
                else s.begin(true)
            } else s?.stop()
            refresh()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun needService() {
        Toast.makeText(this, "Game Cleaner ل Accessibility بکەڤە کار", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun refresh() {
        val s = ClearService.inst
        ignore = true; sw.isChecked = s?.active == true; ignore = false
        status.text = when {
            s == null -> "خزمەت ڤەمرییە. ل Accessibility بکەڤە کار."
            s.active -> "کار دکەت… ب دوگمەیا OFF ڕاوەستینە."
            else -> "ئامادەیە."
        }
    }

    override fun onResume() { super.onResume(); refresh() }
}
